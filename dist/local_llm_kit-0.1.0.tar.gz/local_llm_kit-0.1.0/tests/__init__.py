"""
Test package for local_llm_kit.
""" 