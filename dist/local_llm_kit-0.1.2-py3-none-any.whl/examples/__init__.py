"""
Example scripts for local_llm_kit.
""" 